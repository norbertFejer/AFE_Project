# AFE_Project
Automatic Feature Extraction Using Deep Neural Models
